@bot.on(events.NewMessage(pattern="/start"))
async def menu(event):
	inline = [
[Button.url("< ADMIN PANEL >>","menu")],
[Button.url("[ TELEGRAM ]","https://t.me/dotycat"),
Button.url("[ YOUTUBE ]","https://t.me/dotycat")],
[Button.url("< FREE VPN SERVICES >>","https://dotycat.com")]]

		msg = f"""
** 🔥 WELCOME TO SSHXVPN 🔥 **
"""
await event.reply(msg,buttons=inline)